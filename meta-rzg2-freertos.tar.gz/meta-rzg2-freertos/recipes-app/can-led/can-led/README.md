# canLed Application
canLed is a sample demo application to demonstrate communication between CR7 (running FreeRTOS) and CA5x (running Linux).
  - CAN0 (0xe6c30000) interface will be owned by CR7 (FreeRTOS)
  - CAN1 (0xe6c38000) interface will be owned by CA5x (Linux)

## Prerequisites
	- CAN0 (0xe6c30000) is disabled in DT
	- CAN1 (0xe6c38000) is enabled in DT (will be populated as can0 when booted into Linux)
	- CAN0 and CAN1 interface are connected using loopback cable
	- can-utils is installed as part of Linux rootfs
	- ARM64 cross-compiler toolchain is installed on Host PC

## Compile

	$ autoreconf -vfi
	$ ./configure --host=aarch64 CC=aarch64-linux-gnu-gcc
	$ make

The above command will build an application named canLed

## Application options
	* "-c" #CAN channel to select by default can0 interface will be used.
	* "-b" #Baudrate to be configured on the CAN channel by default 1M will be used.
	* "-i" #Specifies the number of microseconds after which a CAN frame should be sent to turn ON the LED. By default the period is 300000 microseconds.
	* "-o" #Specifies the number of microseconds after which a CAN frame should be sent to turn OFF the LED. By default the period is 200000 microseconds.
	* "-h" #Prints out the information on usage of this application.

## Running the application
 `$ canLed <options>`

Application will run with default values

## Note:
 For RZ/G2M Rev.[2.0/3.0/4.0] the CAN interface should always be can0 and baud-rate set to 1M
