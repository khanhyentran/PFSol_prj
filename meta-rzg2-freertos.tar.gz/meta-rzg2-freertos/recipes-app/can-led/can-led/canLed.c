/*
 * Copyright (c) 2020, Renesas Electronics Corporation
 *
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Application periodically sends CAN frame to turn ON/OFF LED2 on G2M board.
 */

#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>

#define CAN_DEFAULT_BITRATE		1000000
#define CAN_LED_DEFAULT_ON_US		300000
#define CAN_LED_DEFAULT_OFF_US		200000
#define CAN_DEFAULT_INTERFACE		"can0"
#define CAN_ID				123
#define CAN_LED_ON_MESSAGE		"00ff000000000000"
#define CAN_LED_OFF_MESSAGE		"0000000000000000"

static volatile int exit_app = 0;
static long led_on_time = CAN_LED_DEFAULT_ON_US;
static long led_off_time = CAN_LED_DEFAULT_OFF_US;

static unsigned int can_bitrate = CAN_DEFAULT_BITRATE;
static char can_interface[] = CAN_DEFAULT_INTERFACE;

static void sig_handler(int signo)
{
	exit_app = 1;
}

static void *candump_thread(void *arg)
{
	int ret;

	ret = system("candump any,0:0,#FFFFFFFF &");
	if (ret) {
		fprintf(stderr, "%s failed to run candump\n", __func__);
		return NULL;
	}

	while (!exit_app)
		sleep(1);

	return NULL;
}

static void *led_on_off_thread(void *arg)
{
	char off_msg[128];
	char on_msg[128];
	int ret;

	sprintf(off_msg, "cansend %s %d#%s", can_interface, CAN_ID, CAN_LED_OFF_MESSAGE);
	sprintf(on_msg, "cansend %s %d#%s", can_interface, CAN_ID, CAN_LED_ON_MESSAGE);

	while (!exit_app) {
		ret = system(on_msg);
		if (ret) {
			fprintf(stderr, "%s failed to send CAN message to turn ON LED\n", __func__);
			return NULL;
		}
		usleep(led_on_time);

		ret = system(off_msg);
		if (ret) {
			fprintf(stderr, "%s failed to send CAN message to turn OFF LED\n", __func__);
			return NULL;
		}
		usleep(led_off_time);
	}

	return NULL;
}

static int configure_can(void)
{
	char cfg_can[128];
	int ret;

	sprintf(cfg_can, "ip link set %s down", can_interface);
	ret = system(cfg_can);
	if (ret) {
		fprintf(stderr, "%s failed to bring %s interface down\n", __func__, can_interface);
		return -EINVAL;
	}

	sprintf(cfg_can, "ip link set %s up type can bitrate %d", can_interface, can_bitrate);
	ret = system(cfg_can);
	if (ret) {
		fprintf(stderr, "%s failed to bring up %s interface up\n", __func__, can_interface);
		return -EINVAL;
	}

	return 0;
}

static void show_help(char *app)
{
	fprintf(stderr, "%s Usage:\n", app);
	fprintf(stderr, "-b <bitrate> Example: -b 1000000\n");
	fprintf(stderr, "-c <can interface> Example: -c can1\n");
	fprintf(stderr, "-i <ON period timer> Example: -i 100000\n");
	fprintf(stderr, "-o <OFF period timer> Example: -o 30000\n");
	fprintf(stderr, "-h <prints this usage>\n");
	exit(0);
}

int main(int argc, char *argv[])
{
	pthread_t candump_th;
	pthread_t led_th;
	char *endptr;
	int ret;
	int opt;

	while((opt = getopt(argc, argv, "b:c:i:o:h")) != -1) {
		switch(opt) {
		case 'b':
			can_bitrate = strtol(optarg, &endptr, 10);
			 if ((errno == ERANGE &&
			     (can_bitrate == LONG_MAX ||
			     can_bitrate == LONG_MIN)) ||
			     (errno != 0 && can_bitrate == 0))
				 can_bitrate = CAN_DEFAULT_BITRATE;
			break;
		case 'c':
			if (strlen(optarg) && strstr(optarg, "can"))
				strcpy(can_interface, optarg);
			break;
		case 'i':
			led_on_time = strtol(optarg, &endptr, 10);
			 if ((errno == ERANGE &&
			     (led_on_time == LONG_MAX ||
			     led_on_time == LONG_MIN)) ||
			     (errno != 0 && led_on_time == 0))
				 led_on_time = CAN_LED_DEFAULT_ON_US;
			break;
		case 'o':
			led_off_time = strtol(optarg, &endptr, 10);
			 if ((errno == ERANGE &&
			     (led_off_time == LONG_MAX ||
			     led_off_time == LONG_MIN)) ||
			     (errno != 0 && led_off_time == 0))
				 led_off_time = CAN_LED_DEFAULT_OFF_US;
			break;
		case 'h':
		default:
			show_help(argv[0]);
			break;
		}
	}

	ret = configure_can();
	if (ret)
		return 0;

	if (signal(SIGINT, sig_handler) == SIG_ERR ||
	    signal(SIGHUP, sig_handler) == SIG_ERR) {
		fprintf(stderr, "Failed to add signal handler\n");
		return 0;
	}

	ret = pthread_create(&candump_th, NULL,
			     candump_thread, (void*)NULL);
	if (ret) {
		fprintf(stderr, "Failed to create candump thread\n");
		goto quit_main;
	}

	ret = pthread_create(&led_th, NULL,
			     led_on_off_thread, (void*)NULL);
	if (ret) {
		fprintf(stderr, "Failed to create led_on_off_thread thread\n");
		goto quit_main;
	}

	while (!exit_app)
		sleep(1);

quit_main:
	exit_app = 1;

	return 0;
}
