# OpenEmbedded/Yocto FreeRTOS layer for Renesas RZ/G2 SoCs
This layer provides support for Renesas RZ/G2 reference platforms for use with OpenEmbedded/Yocto.

Layer maintainer: Lad, Prabhakar <prabhakar.mahadev-lad.rj@bp.renesas.com>

## Supported Boards/Machines
* hihope-rzg2m (R8A774A1)

## Prerequisites
* Flash writer application [[1]](#link1) (refer [[2]](#link2) for compilation)

## Build Dependencies
The meta-rzg2-freertos layer is developed on top of BSP-1.0.4 release
[[3]](#link3), so make sure you have checked out the proper release, following
are the commit-ids for individual meta-layers used in BSP-1.0.4 release.

* poky
  * URI: http://git.yoctoproject.org/cgit/cgit.cgi/poky
  * commit-id: 7e7ee662f5dea4d090293045f7498093322802cc

* meta-linaro
  * URI: https://git.linaro.org/openembedded/meta-linaro.git/
  * commit-id: 75dfb67bbb14a70cd47afda9726e2e1c76731885

* meta-openembeded
  * URI: https://github.com/openembedded/meta-openembedded
  * commit-id: 352531015014d1957d6444d114f4451e241c4d23

* meta-gplv2
  * URI: http://git.yoctoproject.org/cgit.cgi/meta-gplv2
  * commit-id: f875c60ecd6f30793b80a431a2423c4b98e51548

* meta-qt5
  * URI: https://github.com/meta-qt5/meta-qt5.git
  * commit-id: c1b0c9f546289b1592d7a895640de103723a0305

* meta-rzg2
  * URI: https://github.com/renesas-rz/meta-rzg2.git
  * commit-id: 254953bd4f3f263f826d2208c82e7ad895bbaaa7

## Build Instructions for hihope-rzg2m
1. Traverse to top level where all meta layers are present, and initialize the
environment using following command:

    `$ source poky/oe-init-build-env`

    Note: after this step current working directly will be changed to "build"

2. Copy the bblayers.conf and local.conf file from
"meta-rzg2-freertos/docs/sample/conf/hihope-rzg2m/<toolchain>/" to "build/conf"

    `$ cp ${WORK}/meta-rzg2-freertos/docs/sample/conf/hihope-rzg2m/<toolchain>/*.conf ./conf/.`

3. Issue bitbake command to build the image

    `$ bitbake core-image-bsp`

## Flashing Images
* Refer to section 3 of the Yocto recipe Start-Up Guide Rev.1.04

## License
This project is licensed under the terms of the MIT license (please see file
*COPYING.MIT* in this directory for further details).

## References
<a name="link1"></a>[1] https://github.com/renesas-rz/rzg2_flash_writer  
<a name="link2"></a>[2] https://github.com/renesas-rz/rzg2_flash_writer/blob/master/README.md  
<a name="link3"></a>[3] https://github.com/renesas-rz/meta-rzg2/tree/BSP-1.0.4  
