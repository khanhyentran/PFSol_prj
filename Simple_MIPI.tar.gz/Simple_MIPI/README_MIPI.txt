This code demonstrates how to use the MIPI to capture images from the camera.

This code works with RASPBERRY Pi CAMERA V2 (Sony imx219).

----------------------------------------
Building
----------------------------------------
First set the BSP build environment

	$ ./build.sh env
	$ export ROOTDIR=$(pwd) ; source ./setup_env.sh

Then you can build the applicaiton:

	$ make

By doing a 'make install' will copy to your buildroot overlay directory. But, make sure
to rebuild buildroot to add it to your image to program into the board. For example:
	$ make install
	$ cd ..
	$ ./build.sh buildroot

Just for Khanh to build:
/home/rvc/RZA_prj/02_uboot_drivermodel/rza_linux-4.9_bsp/output/buildroot-2017.02/output/host/usr/bin/arm-linux-gnueabihf-gcc -static -O2 --sysroot=/home/rvc/RZA_prj/02_uboot_drivermodel/rza_linux-4.9_bsp/output/buildroot-2017.02/output/host/usr/arm-buildroot-linux-gnueabihf/sysroot/ -o mipi_app mipi_main.c camera_mipi_imx219.c mipi.c

cp mipi_main rza_linux-4.14_bsp/output/buildroot-2017.02/output/rootfs_overlay/root/
cd rza_linux-4.14_bsp/output/buildroot-2017.02/
make
cd ../../../debug_VIN/rza_linux-4.14_misano/
./build.sh  jlink_rootfs /data1/KhanhTran/rza_linux-4.14_bsp/output/buildroot-2017.02/output/images/rootfs.axfs
----------------------------------------
Pin setup
----------------------------------------
This code assumes you have taken care of the MIPI pin setup in u-boot or the kernel.

----------------------------------------
MIPI Capture Buffer Address
----------------------------------------
Some setup is needed in the mipi_main.c file for your board.

You must hard code a RAM location for the MIPI to capture images to.
This is done at the top of the file:
static unsigned int cap_buf_addr = 40200000;	/* 2MB offset in internal RAM */
static unsigned int cap_buf_size = (1*1024*1024); 	/* Capture buffer size */

You cannot simply 'malloc' this RAM in the application because you need to use a
physical RAM address (not virutal address) and the memory must be continuous (not paged)

----------------------------------------
Misano Board
----------------------------------------
