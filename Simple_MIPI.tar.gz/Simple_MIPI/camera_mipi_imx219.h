void MIPI_RIIC_INIT();
void MIPI_RIIC_CLOSE();
int R_MIPI_CameraPowOn(void);
int R_MIPI_CameraClkStart(void);
int R_MIPI_CameraClkStop(void);
int R_MIPI_CameraReset(void);
