// SPDX-License-Identifier: GPL-2.0
#include "common.h"

extern const struct renesas_usbhs_platform_callback usbhs_rcar3_ops;
extern const struct renesas_usbhs_platform_callback usbhs_rcar3_with_pll_ops;
