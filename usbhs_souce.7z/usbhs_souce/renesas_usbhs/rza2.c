// SPDX-License-Identifier: GPL-2.0
/*
 * Renesas USB driver RZ/A initialization and power control
 *
 * Copyright (C) 2018 Chris Brandt
 * Copyright (C) 2018 Renesas Electronics Corporation
 */

#include <linux/delay.h>
#include <linux/io.h>
#include <linux/of_device.h>
#include <linux/phy/phy.h>
#include "common.h"
#include "rza2.h"


static int usbhs_rza2_hardware_init(struct platform_device *pdev)
{
	struct usbhs_priv *priv = usbhs_pdev_to_priv(pdev);
	if (IS_ENABLED(CONFIG_GENERIC_PHY)) {
		struct phy *phy = phy_get(&pdev->dev, "usb");

		if (IS_ERR(phy))
			return PTR_ERR(phy);

		priv->phy = phy;
		return 0;
	}
	return -ENXIO;
}

static int usbhs_rza2_hardware_exit(struct platform_device *pdev)
{
	struct usbhs_priv *priv = usbhs_pdev_to_priv(pdev);

	if (priv->phy) {
		phy_put(priv->phy);
		priv->phy = NULL;
	}

	return 0;
}

static int usbhs_rza2_power_ctrl(struct platform_device *pdev,
				void __iomem *base, int enable)
{
	struct usbhs_priv *priv = usbhs_pdev_to_priv(pdev);
	int retval = -ENODEV;

	if (priv->phy) {
		if (enable) {
			retval = phy_init(priv->phy);

			if (!retval)
				retval = phy_power_on(priv->phy);
		} else {
			usbhs_bset(priv, LPSTS, LPSTS_SUSPM, 0);
			phy_power_off(priv->phy);
			phy_exit(priv->phy);
			retval = 0;
		}
	}

	return retval;
}

static int usbhs_rza2_get_vbus(struct platform_device *pdev){
	uint16_t buf1;
    uint16_t buf2;
    uint16_t buf3;
    struct usbhs_priv *priv = usbhs_pdev_to_priv(pdev);
    int connect_flg = 0;

    /* VBUS chattering cut */
    do {
        buf1 = usbhs_read(priv, INTSTS0);
        udelay(10);
        buf2 = usbhs_read(priv, INTSTS0);
        udelay(10);
        buf3 = usbhs_read(priv, INTSTS0);
    } while (((buf1 & VBSTS) != (buf2 & VBSTS)) || ((buf2 & VBSTS) != (buf3 & VBSTS)));

    /* VBUS status judge */
    if ((buf1 & VBSTS) != (uint16_t)0) {
        connect_flg = 1;
    }

    return connect_flg;
}

static int usbhs_rza2_get_id(struct platform_device *pdev)
{
	return USBHS_GADGET;
}

const struct renesas_usbhs_platform_callback usbhs_rza2_ops = {
	.hardware_init = usbhs_rza2_hardware_init,
	.hardware_exit = usbhs_rza2_hardware_exit,
	.power_ctrl = usbhs_rza2_power_ctrl,
	// .get_vbus = usbhs_rza2_get_vbus,
	.get_id = usbhs_rza2_get_id,
};
