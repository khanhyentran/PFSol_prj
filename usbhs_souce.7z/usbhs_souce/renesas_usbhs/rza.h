// SPDX-License-Identifier: GPL-2.0
#include "common.h"

extern const struct renesas_usbhs_platform_callback usbhs_rza1_ops;
