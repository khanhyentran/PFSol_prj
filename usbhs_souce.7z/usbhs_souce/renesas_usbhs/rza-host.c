/*
 * Renesas USB driver RZ/A initialization
 *
 * Copyright (C) 2017 Chris Brandt
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 */

#include <linux/gpio.h>
#include <linux/of_gpio.h>
#include <linux/phy/phy.h>
#include <linux/usb/phy.h>
#include "common.h"
#include "rza.h"

static int usbhs_rza_hardware_init(struct platform_device *pdev)
{
	struct usbhs_priv *priv = usbhs_pdev_to_priv(pdev);
	u16 value;

	/*
	 * Selects the clock to be supplied to this module from 48-MHz USB_X1 or
	 * 12-MHz EXTAL.
	 * 0: The 48-MHz USB_X1 clock is selected.
	 * 1: The 12-MHz EXTAL clock is selected.
	 * 
	 * NOTE: This register is only in USB ch 0, so if you want to use
	 * ch1, you must enabel ch0 first
	 */
//TODO: check to see if USB_X1 signal exists in DT
//	value = ioread16(priv->base + SYSCFG0);
//	value |= UCKSEL;
//	iowrite16(value, priv->base + SYSCFG0);

	/*
	 * Enables operation of the internal PLL
	 * NOTE: This register is only in USB ch 0, so if you want to use
	 * ch1, you must enable ch0 first.
	 */
	msleep(20);
	value = ioread16(priv->base + SYSCFG);
	value |= UPLLE;
	iowrite16(value, priv->base + SYSCFG);

	msleep(20);
//	r8a66597_bset(r8a66597, SUSPM, SUSPMODE0);
	iowrite16( BIT(14), priv->base + SUSPMODE);

	return 0;
}

static int usbhs_rza_hardware_exit(struct platform_device *pdev)
{
	//struct usbhs_priv *priv = usbhs_pdev_to_priv(pdev);


	return 0;
}

static int usbhs_rza_get_id(struct platform_device *pdev)
{
	//return USBHS_GADGET;
	return USBHS_HOST;
}

const struct renesas_usbhs_platform_callback usbhs_rza_ops = {
	.hardware_init = usbhs_rza_hardware_init,
	.hardware_exit = usbhs_rza_hardware_exit,
	.get_id = usbhs_rza_get_id,
};
