/*
 * Copyright (C) 2018 Renesas Electronics Corporation
 * Copyright (C) 2018 Chris Brandt
 *
 * This file is released under the terms of GPL v2 and any later version.
 * See the file COPYING in the root directory of the source tree for details.
 */

#include <common.h>
#include <asm/arch/r7s9210.h>
#include <asm/arch/sys_proto.h>
#include <dm/platform_data/serial_sh.h>
#include <i2c.h>
#include <spi_flash.h>
#include <netdev.h>
#include <asm/arch/mmc.h>
#include <asm/arch/sh_sdhi.h>

//#define DEBUG

DECLARE_GLOBAL_DATA_PTR;

/* Serial Console */
static const struct sh_serial_platdata serial_platdata = {
	.base = SCIF_CONSOLE_BASE,	/* SCIFx_BASE */
	.type = PORT_SCIF,		/* SCIF (not a SCIFA) */
	.clk = CONFIG_SYS_CLK_FREQ,	/* P1 Clock */
};
U_BOOT_DEVICE(rza2mevb_serial) = {
	.name = "serial_sh",
	.platdata = &serial_platdata,
};



#define PFC_BASE	0xFCFFE000
#define PDR_BASE	(PFC_BASE + 0x0000)	/* 16-bit, 2 bytes apart */
#define PODR_BASE	(PFC_BASE + 0x0040)	/* 8-bit, 1 byte apart */
#define PIDR_BASE	(PFC_BASE + 0x0060)	/* 8-bit, 1 byte apart */
#define PMR_BASE	(PFC_BASE + 0x0080)	/* 8-bit, 1 byte apart */
#define DSCR_BASE	(PFC_BASE + 0x0140)	/* 16-bit, 2 bytes apart */
#define PFS_BASE	(PFC_BASE + 0x0200)	/* 8-bit, 8 bytes apart */
#define PWPR		(PFC_BASE + 0x02FF)	/* 8-bit */
#define PFENET		(PFC_BASE + 0x0820)	/* 8-bit */
#define PPOC		(PFC_BASE + 0x0900)	/* 32-bit */
#define PHMOMO		(PFC_BASE + 0x0980)	/* 32-bit */
#define PMODEPFS	(PFC_BASE + 0x09C0)	/* 32-bit */
#define PCKIO		(PFC_BASE + 0x09D0)	/* 8-bit */


void pfc_set_pin_function(u8 port, u8 pin, u8 func)
{
	u16 reg16;
	u16 mask16;

	/* Set pin to 'Non-use (Hi-z input protection)'  */
	reg16 = *(volatile u16 *)(PDR_BASE + (port * 2));
	mask16 = 0x03 << (pin * 2);
	reg16 &= ~mask16;
	*(volatile u16 *)(PDR_BASE + port * 2) = reg16;

	/* Temporary switch to GPIO */
	*(volatile u8 *)(PMR_BASE + port) &= ~(1 << pin);

	/* PFS Register Write Protect : OFF */
	*(volatile u8 *)PWPR = 0x00; /* B0WI=0, PFSWE=0 */
	*(volatile u8 *)PWPR = 0x40; /* B0WI=0, PFSWE=1 */

	/* Set Pin function (interrupt disabled, ISEL=0) */
	*(volatile u8 *)(PFS_BASE + (port * 8) + pin) = func;

	/* PFS Register Write Protect : ON */
	*(volatile u8 *)PWPR = 0x00; /* B0WI=0, PFSWE=0 */
	*(volatile u8 *)PWPR = 0x80; /* B0WI=1, PFSWE=1 */

	/* Port Mode  : Peripheral module pin functions */
	*(volatile u8 *)(PMR_BASE + port) |= (1 << pin);
}

#define GPIO_IN 0
#define GPIO_OUT 1
void pfc_set_gpio(u8 port, u8 pin, u8 dir)
{
	u16 reg16;
	u16 mask16;

	reg16 = *(volatile u16 *)(PDR_BASE + (port * 2));
	mask16 = 0x03 << (pin * 2);
	reg16 &= ~mask16;

	if (dir == GPIO_IN)
		reg16 |= 2 << (pin * 2);	// pin as input
	else
		reg16 |= 3 << (pin * 2);	// pin as output

	*(volatile u16 *)(PDR_BASE + port * 2) = reg16;
}


void gpio_set(u8 port, u8 pin, u8 value)
{
	if (value)
		*(volatile u8 *)(PODR_BASE + port) |= (1 << pin);
	else
		*(volatile u8 *)(PODR_BASE + port) &= ~(1 << pin);
}

u8 gpio_read(u8 port, u8 pin)
{
	return (*(volatile u8 *)(PIDR_BASE + port) >> pin) & 1;
}


/*
================================
SWx-1 SDRAM/DRP,Other
================================
P0_0	DB0		DRP24
P0_1	DB1		DRP25
P0_2	DB2		DRP26
P0_3	DB3		DRP27
P0_4	DB4		DRP28
P0_5	DB5		DRP29
P0_6	DB6		DRP30
P1_0	DB7		2_P1_0
P1_1	DB8		2_P1_1/CAN0RX
P1_3	DB10		2_P1_3/CAN0TX
P2_0	DB12		2_P2_0/CAN1RX
P2_2	DB14		2_P2_2/CAN1TX
P6_5	1_P6_5/CS3	DRP1
P6_7	1_P6_7/DQML	DRP3
P7_0	1_P7_0		DRP4
P7_1	1_P7_1		DRP5
P7_3	1_P7_3		DRP6
P7_4	1_P7_4		DRP7
P7_5	1_P7_5		2_P7_5
P8_1	A1		DRP23
P8_2	A2		DRP22
P8_3	A3		DRP21
P8_4	A4		2_P8_4
P8_5	A5		DRP19
P8_6	A6		2_P8_6
P8_7	A7		2_P8_7
P9_0	A8		2_P9_0
P9_1	A9		2_P9_1
P9_2	A10		DRP14
P9_3	A11		2_P9_3
P9_4	A12		2_P9_4
P9_5	A13		2_P9_5
P9_6	A14		2_P9_6
P9_7	A15		DRP9

	================================
	SWx-1 (DRP/Audio)
	================================
	2_P8_4	DRP20	22_P8_4_SSL00
	2_P8_4	DRP18	22_P8_6
	2_P8_4	DRP17	22_P8_7
	P6_4	DRP0	22_P6_4/AUDIO_CLK
	2_P9_4	DRP13	22_P9_3
	2_P9_4	DRP12	22_P9_4
	2_P9_4	DRP11	22_P9_5
	2_P9_6	DRP10	22_P9_6

	================================
	SWx-3 (DRP/UART,CAN,USB)
	================================
	2_P9_0	DRP16	22_P9_0/TxD4
	2_P9_1	DRP15	22_P9_1/RxD4
	2_P1_0	DRP31	22_P1_0/CAN_CLK
	2_P7_5	DRP8	22_P7_5/OVRCUR1

================================
SWx-4 Ether1/CEU
================================
P6_1	1_P6_1	2_P6_1
P6_2	1_P6_2	2_P6_2
P6_3	1_P6_3	2_P6_3
PE_0	1_PE_0	2_PE_0
PE_1	1_PE_1	2_PE_1
PE_2	1_PE_2	2_PE_2
PE_3	1_PE_3	2_PE_3
PE_4	1_PE_4	2_PE_4
PE_5	1_PE_5	2_PE_5
PE_6	1_PE_6	2_PE_6

================================
SWx-5 Ether2/NAND
================================
P3_1	1_P3_1	2_P3_1
P3_2	1_P3_2	2_P3_2
P3_3	1_P3_3	2_P3_3
P3_4	1_P3_4	2_P3_4
P3_5	1_P3_5	2_P3_5
PH_5	1_PH_5	2_PH_5
PK_0	1_PK_0	2_PK_0
PK_1	1_PK_1	2_PK_1
PK_2	1_PK_2	2_PK_2
PK_3	1_PK_3	2_PK_3
PK_4	1_PK_4	2_PK_4

================================
SWx-6 VDC6/NAND
================================
PJ_6	1_PJ_6	2_PJ_6
PJ_7	1_PJ_7	2_PJ_7

================================
SWx-7 VDC6/SIM
================================
PA_4	1_PA_4	2_PA_4
PA_5	1_PA_5	2_PA_5
PA_6	1_PA_6	2_PA_6
PA_7	1_PA_7	2_PA_7

*/

static uint16_t HyperRAM_ReadConfig0(void)
{
	uint16_t config0;

	*(volatile u32 *)HYPER_MCR1 |= (1 << 5);	//CRT = 1      /* io space */
	*(volatile u32 *)HYPER_MCR1;	/* dummy read */

	/* Read Configuration0 */
	config0 = *(u16 *) (0x40000000 + (0x800 << 1) );

	*(volatile u32 *)HYPER_MCR1 &= ~(1 << 5);	// CRT = 0      /* memory space */
	*(volatile u32 *)HYPER_MCR1;	/* dummy read */

	return config0;
}

static void HyperRAM_WriteConfig0(u16 config0)
{
	*(volatile u32 *)HYPER_MCR1 |= (1 << 5);	//CRT = 1      /* io space */
	*(volatile u32 *)HYPER_MCR1;	/* dummy read */

	*(volatile u16 *)(0x40000000 + (0x800 << 1) ) = config0;

	*(volatile u32 *)HYPER_MCR1 &= ~(1 << 5);	// CRT = 0      /* memory space */
	*(volatile u32 *)HYPER_MCR1;	/* dummy read */
}

void HyperRAM_Init(void)
{
	u32 val;
	u16 config0;

	/* SCLKSEL Setting */
	*(volatile u16 *)SCLKSEL |= (3 << 4); /* Hyper Clock = G/2phy */

	/* MCR0 Setting */
	val = 	(0 << 31) |	// MAXEN = 0
		(0 << 18) |	// MAXLEN = 0
		(0 << 5) |	// CRT = 0      /* memory space */
		(0 << 4) |	// DEVTYPE = 0  /* HyerRAM */
		(3 << 0);	// WRAPSIZE = 3 /* 32Byte  */
	*(volatile u32 *)HYPER_MCR0 = val;

	/* MCR1 Setting */
	val = 	(0 << 31) |	// MAXEN = 0
		(0 << 18) |	// MAXLEN = 0
		(0 << 5) |	// CRT = 0      /* memory space */
		(1 << 4) |	// DEVTYPE = 1  /* HyerRAM */
		(3 << 0);	// WRAPSIZE = 3 /* 32Byte  */
	*(volatile u32 *)HYPER_MCR1 = val;

	val = 	(0 << 28) |	// RCSHI = 0; /* 1.5 clock */
		(0 << 24) |	// WCSHI = 0; /* 1.5 clock */
		(0 << 20) |	// RCSS = 0;  /* 1 clock */
		(0 << 16) |	// WCSS = 0;  /* 1 clock */
		(0 << 12) |	// RCSH = 0;  /* 1 clock */
		(0 <<  8) |	// WCSH = 0;  /* 1 clock */
		(1 <<  0);	// LTCY = 1;  /* 6 clock Latency */
	*(volatile u32 *)HYPER_MTR0 = val;

	val = 	(0 << 28) |	// RCSHI = 0; /* 1.5 clock */
		(0 << 24) |	// WCSHI = 0; /* 1.5 clock */
		(0 << 20) |	// RCSS = 0;  /* 1 clock */
		(0 << 16) |	// WCSS = 0;  /* 1 clock */
		(0 << 12) |	// RCSH = 0;  /* 1 clock */
		(0 <<  8) |	// WCSH = 0;  /* 1 clock */
		(1 <<  0);	// LTCY = 1;  /* 6 clock Latency */
	*(volatile u32 *)HYPER_MTR1 = val;

	/* Dedicated Pin POC Control Register (PPOC) Setting */
	*(volatile u32 *)PPOC =
			1 * (1 << 9) |	/* POCSEL1 (1=POC1 is valid) */
			1 * (1 << 8) |	/* POCSEL0 (1=POC0 is valid) */
			0 * (1 << 3) |	/* POC3 SDMMC1 (0=1.8v, 1=3.3v) */
			0 * (1 << 2) |	/* SDMMC0 (0=1.8v, 1=3.3v) */
			0 * (1 << 1) |	/* POC1 Hyper (0=1.8v, 1=3.3v) */
			1 * (1 << 0);	/* POC0 QSPI (0=1.8v, 1=3.3v) */

	/* PHMOMO Setting */
	*(volatile u32 *)PHMOMO = 0xFFFFFFFE; /* Select HyperBus */

//	config0 = HyperRAM_ReadConfig0();

//	config0 = (config0 & 0xff07);	/* bit[7:4]= b'0000 :Latency:5 cycle */
					/* bit[3] = 0 : Variable Latency */

//	HyperRAM_WriteConfig0(config0);

//	*(volatile u32 *)HYPER_MTR1 &= ~1;	// LTCY=0 (5 clock Latency)
//	*(volatile u32 *)HYPER_MTR1;          /* dummy read */

//	config0 = HyperRAM_ReadConfig0();
}



int board_early_init_f(void)
{
	/* This function runs early in the boot process, before u-boot is relocated
	   to RAM (hence the '_f' in the function name stands for 'still running from
	   flash'). A temporary stack has been set up for us which is why we can
	   have this as C code. */

#define L2CACHE_8WAY    (0x000000FFuL)  /* All entries(8way) in the L2 cache */

	/* ==== Disable L2 cache ==== */
	PL310_REG(REG1_CONTROL) = 0x00000000uL;	/* Disable L2 cache */

	/* ==== Cache Sync ==== */
	/* Ensures completion of the L2 cache disable operation */
	PL310_REG(REG7_CACHE_SYNC) = 0x00000000uL;

	/* ==== Invalidate all L2 cache by Way ==== */
	/* Set "1" to Way bits[7:0] of the reg7_inv_way register */
	PL310_REG(REG7_INV_WAY) = L2CACHE_8WAY;

	/* Wait until Way bits[7:0] is cleared */
	while ( (PL310_REG(REG7_INV_WAY) & L2CACHE_8WAY) != 0x00000000uL) { /* Wait completion */ }

	/* ==== Cache Sync ==== */
	/* Ensures completion of the invalidate operation */
	PL310_REG(REG7_CACHE_SYNC) = 0x00000000uL;

	/* ==== Enable L2 cache ==== */
	PL310_REG(REG2_INT_CLEAR) = 0x000001FFuL;	/* Clear the reg2_int_raw_status register */
	PL310_REG(REG9_D_LOCKDOWN0) = 0x00000000uL;
	PL310_REG(REG1_CONTROL) = 0x00000001uL;		/* Enable L2 cache */

	/* =========== Pin Setup =========== */
	/* Adjust for your board as needed. */

	/* Serial Console */
#if (SW6_1 != SW_OFF) || (SW6_3 != SW_OFF)
	#error "Switch SW6 conflict: SCIF4 UART Pins not enabled. See top of file rza2mevb.h"
#else
	pfc_set_pin_function(P9, 0, 4);	/* P9_0 = TxD4 */
	pfc_set_pin_function(P9, 1, 4);	/* P9_1 = RxD4 */
#endif


	/* RIIC Ch 3 */
#if 0 /*** PLEASE configure pins and 'ALTx' according to Tables 54.xx in the Hardware Manual ***/
	pfc_set_pin_function(1, 6, ALT1, 0, 1);	/* P1_6 = RIIC3SCL (bi dir) */
	pfc_set_pin_function(1, 7, ALT1, 0, 1);	/* P1_7 = RIIC3SDA (bi dir) */
#endif

	/* Ethernet */
#if 1
/** RMII mode **/
	/* Channel 0 */
	pfc_set_pin_function(PE, 0, 7); /* REF50CK0 */
	pfc_set_pin_function(P6, 1, 7); /* RMMI0_TXDEN */
	pfc_set_pin_function(P6, 2, 7); /* RMII0_TXD0 */
	pfc_set_pin_function(P6, 3, 7); /* RMII0_TXD1 */
	pfc_set_pin_function(PE, 4, 7); /* RMII0_CRSDV */
	pfc_set_pin_function(PE, 1, 7); /* RMII0_RXD0 */
	pfc_set_pin_function(PE, 2, 7); /* RMII0_RXD1 */
	pfc_set_pin_function(PE, 3, 7); /* RMII0_RXER */
	pfc_set_pin_function(PE, 5, 1); /* ET0_MDC */
	pfc_set_pin_function(PE, 6, 1); /* ET0_MDIO */

	/* Channel 1 */
	pfc_set_pin_function(PK, 3, 7); /* REF50CK1 */
	pfc_set_pin_function(PK, 0, 7); /* RMMI1_TXDEN */
	pfc_set_pin_function(PK, 1, 7); /* RMII1_TXD0 */
	pfc_set_pin_function(PK, 2, 7); /* RMII1_TXD1 */
	pfc_set_pin_function(P3, 2, 7); /* RMII1_CRSDV */
	pfc_set_pin_function(PK, 4, 7); /* RMII1_RXD0 */
	pfc_set_pin_function(P3, 5, 7); /* RMII1_RXD1 */
	pfc_set_pin_function(P3, 1, 7); /* RMII1_RXER */
	pfc_set_pin_function(P3, 3, 1); /* ET1_MDC */
	pfc_set_pin_function(P3, 4, 1); /* ET1_MDIO */
#endif

	/* MMC */
#if 0 /*** PLEASE configure pins and 'ALTx' according to Tables 54.xx in the Hardware Manual ***/
	pfc_set_pin_function(3, 8, ALT8, 0, 0);		/* MMC CD */
	pfc_set_pin_function(3, 10, ALT8, 0, 1);	/* MMC DAT1 (bi dir) */
	pfc_set_pin_function(3, 11, ALT8, 0, 1);	/* MMC DAT0 (bi dir) */
	pfc_set_pin_function(3, 12, ALT8, 0, 0);	/* MMC CLK */
	pfc_set_pin_function(3, 13, ALT8, 0, 1);	/* MMC CMD (bi dir) */
	pfc_set_pin_function(3, 14, ALT8, 0, 1);	/* MMC DAT3 (bi dir) */
	pfc_set_pin_function(3, 15, ALT8, 0, 1);	/* MMC DAT2 (bi dir)*/
	pfc_set_pin_function(4, 0, ALT8, 0, 1);		/* MMC DAT4 (bi dir)*/
	pfc_set_pin_function(4, 1, ALT8, 0, 1);		/* MMC DAT5 (bi dir) */
	pfc_set_pin_function(4, 2, ALT8, 0, 1);		/* MMC DAT6 (bi dir) */
	pfc_set_pin_function(4, 3, ALT8, 0, 1);		/* MMC DAT7 (bi dir) */
#endif

	/* SDHI */
#if 0 /*** PLEASE configure pins and 'ALTx' according to Tables 54.xx in the Hardware Manual ***/
	pfc_set_pin_function(3, 8, ALT7, 0, 0);		/* SD_CD_1 */
	pfc_set_pin_function(3, 9, ALT7, 0, 0);		/* SD_WP_1 */
	pfc_set_pin_function(3, 10, ALT7, 0, 1);	/* SD_D1_1 (bi dir) */
	pfc_set_pin_function(3, 11, ALT7, 0, 1);	/* SD_D0_1 (bi dir) */
	pfc_set_pin_function(3, 12, ALT7, 0, 0);	/* SD_CLK_1 */
	pfc_set_pin_function(3, 13, ALT7, 0, 1);	/* SD_CMD_1 (bi dir) */
	pfc_set_pin_function(3, 14, ALT7, 0, 1);	/* SD_D3_1 (bi dir) */
	pfc_set_pin_function(3, 15, ALT7, 0, 1);	/* SD_D2_1 (bi dir) */
#endif

	/* SDRAM */
#if 0 /*** PLEASE configure pins and 'ALTx' according to Tablboard_early_init_fes 54.xx in the Hardware Manual ***/

#if (SW6_1 != SW_ON)
	#error "Switch SW6 conflict: SDRAM Pins not enabled. See top of file rza2mevb.h"
#else
	pfc_set_pin_function(5, 8, ALT6, 0, 0);	/* P5_8 = CS2 */
	for(i=0;i<=15;i++)
		pfc_set_pin_function(6, i, ALT1, 0, 1);	/* P6_0~15 = D0-D15 (bi dir) */
	pfc_set_pin_function(7, 2, ALT1, 0, 0);	/* P7_2 = RAS */
	pfc_set_pin_function(7, 3, ALT1, 0, 0);	/* P7_3 = CAS */
	pfc_set_pin_function(7, 4, ALT1, 0, 0);	/* P7_4 = CKE */
	pfc_set_pin_function(7, 5, ALT1, 0, 0);	/* P7_5 = RD/WR */
	pfc_set_pin_function(7, 6, ALT1, 0, 0);	/* P7_6 = WE0/DQMLL */
	pfc_set_pin_function(7, 7, ALT1, 0, 0);	/* P7_7 = WE1/DQMLU */
	for(i=9;i<=15;i++)
		pfc_set_pin_function(7, i, ALT1, 0, 0);	/* P7_9~15: A1-A7 */
	for(i=0;i<=15;i++)
		pfc_set_pin_function(8, i, ALT1, 0, 0);	/* P8_0~15 = A8-A23 */
#endif

#endif

	/* Parallel NOR Flash */
#if 0 /*** PLEASE configure pins and 'ALTx' according to Tables 54.xx in the Hardware Manual ***/
	/* Assumes previous SDRAM setup A1-A23,D0-D15,WE0 */
	pfc_set_pin_function(9, 0, ALT1, 0, 0);	/* P9_0 = A24 */
	pfc_set_pin_function(9, 1, ALT1, 0, 0);	/* P9_1 = A25 */
	pfc_set_pin_function(7, 8, ALT1, 0, 0);	/* P7_8 = RD */
	pfc_set_pin_function(7, 0, ALT1, 0, 0);	/* P7_0 = CS0 */
#endif

	/* LED */
	pfc_set_gpio(P6, 0, GPIO_OUT); /* P6_0 = GPIO_OUT */
	pfc_set_gpio(PC, 1, GPIO_OUT); /* PC_1 = GPIO_OUT */
	//led_red_set_state(1);
	//led_green_set_state(1);

	/* Button */
#if 0
	pfc_set_gpio(1, 9, GPIO_IN); /* P1_9 = GPIO_IN */
#endif

	/**********************************************/
	/* Configure NOR Flash Chip Select (CS0, CS1) */
	/**********************************************/
#ifdef CONFIG_SYS_FLASH_BASE
	#define CS0WCR_D	0x00000b40
	#define CS0BCR_D	0x10000C00
	#define CS1WCR_D	0x00000b40
	#define CS1BCR_D	0x10000C00
	*(u32 *)CS0WCR = CS0WCR_D;
	*(u32 *)CS0BCR = CS0BCR_D;
	*(u32 *)CS1WCR = CS1WCR_D;
	*(u32 *)CS1BCR = CS1BCR_D;
#endif

	/* Hyper RAM */
	HyperRAM_Init();


/* NOTE: You can't use SDRAM and SCIF4 (serial console) at the same time because
         they share the same pins. */
#if 0
	/**********************************************/
	/* Configure SDRAM (CS2, CS3)                 */
	/**********************************************/
	/* Even if you are only using CS2, we need to set up
	   the CS3 register CS3WCR because some bits are common for CS3 and CS2 */

	#define CS2BCR_D	0x00004C00	/* Type=SDRAM, 16-bit memory */
	#define CS2WCR_D	0x00000480	/* CAS Latency = 2 */
	#define CS3BCR_D	0x00004C00	/* Type=SDRAM, 16-bit memory */
	//#define CS3WCR_D	0x00004492	/*  */
	#define CS3WCR_D	2 << 13	|	/* (CS2,CS3) WTRP (2 cycles) */\
				1 << 10 |	/* (CS2,CS3) WTRCD (1 cycle) */\
				1 <<  7 |	/*     (CS3) A3CL (CAS Latency = 2) */\
				2 <<  3 |	/* (CS2,CS3) TRWL (2 cycles) */\
				2 <<  0		/* (CS2,CS3) WTRC (5 cycles) */
	#define SDCR_D		0x00110811	/* 13-bit row, 9-bit col, auto-refresh */

	/*
	 * You must refresh all rows within the amount of time specified in the memory spec.
	 * Total Refresh time =  [Number_of_rows] / [Clock_Source / Refresh Counter]
	 * 63.0ms =  [8192] /  [(66.6MHz / 4) / 128]
	 */
	#define RTCOR_D		0xA55A0080	/* Refresh Counter = 128 */
	#define RTCSR_D		0xA55A0008	/* Clock Source=CKIO/4 (CKIO=66MHz) */

	*(u32 *)CS2BCR = CS2BCR_D;
	*(u32 *)CS2WCR = CS2WCR_D;
	*(u32 *)CS3BCR = CS3BCR_D;
	*(u32 *)CS3WCR = CS3WCR_D;
	*(u32 *)SDCR = SDCR_D;
	*(u32 *)RTCOR = RTCOR_D;
	*(u32 *)RTCSR = RTCSR_D;

	/* wait */
	#define REPEAT_D 0x000033F1
	for (i=0;i<REPEAT_D;i++) {
		asm("nop");
	}

	/* The final step is to set the SDRAM Mode Register by written to a
	   specific address (the data value is ignored) */
	/* Check the hardware manual (table 8.15) if your settings differ */
	/*   Burst Length = 1 (fixed)
	 *   Burst Type = Sequential (fixed)
	 *   CAS Latency = 2 or 3 (see table 8.15)
	 *   Write Burst Mode = [burst read/single write] or [burst read/burst write] (see table 8.15)
	 */
	#define SDRAM_MODE_CS2 0x3FFFD040	/* CS2: CAS=2, burst write, 16bit bus */
	#define SDRAM_MODE_CS3 0x3FFFE040	/* CS3: CAS=2, burst write, 16bit bus */
	*(u16 *)SDRAM_MODE_CS2 = 0;
	*(u16 *)SDRAM_MODE_CS3 = 0;
#endif


	return 0;
}

int board_init(void)
{
	gd->bd->bi_boot_params = (CONFIG_SYS_SDRAM_BASE + 0x100);
	return 0;
}

#ifdef CONFIG_SH_ETHER
int board_eth_init(bd_t *bis)
{
	int ret = -ENODEV;
	ret = sh_eth_initialize(bis);
	return ret;
}
#endif

int board_mmc_init(bd_t *bis)
{
	int ret = 0;
#ifdef CONFIG_SH_MMCIF
	ret = mmcif_mmc_init();
#endif

#ifdef CONFIG_SH_SDHI
	ret = sh_sdhi_init(CONFIG_SYS_SH_SDHI1_BASE, RZ_SDHI_CHANNEL,
			   SH_SDHI_QUIRK_32BIT_BUF);
#endif
	return ret;
}

int board_late_init(void)
{
	u8 mac[6]={0x74, 0x90, 0x50, 0xC0, 0xFE, 0x06};
	if (is_valid_ethaddr(mac))
		eth_setenv_enetaddr("ethaddr", mac);

#if !defined(CONFIG_BOOT_MODE0)
	printf(	"\t\t      SPI Flash Memory Map\n"
		"\t\t------------------------------------\n"
		"\t\t         Start      Size     SPI\n");
	printf(	"\t\tu-boot:  0x%08X 0x%06X 0\n", 0,CONFIG_ENV_OFFSET);
	printf(	"\t\t   env:  0x%08X 0x%06X 0\n", CONFIG_ENV_OFFSET, CONFIG_ENV_SIZE);
	printf(	"\t\t    DT:  0x%08X 0x%06X 0\n", CONFIG_ENV_OFFSET+CONFIG_ENV_SIZE,CONFIG_ENV_SECT_SIZE);
	printf(	"\t\tKernel:  0x%08X 0x%06X 0+1 (size*=2)\n",0x100000, 0x280000);
	printf(	"\t\trootfs:  0x%08X 0x%06X 0+1 (size*=2)\n",0x400000, 0x2000000-0x400000);
#endif

	/* Default addresses */
	#define DTB_ADDR_FLASH		"C0000"		/* Location of Device Tree in QSPI Flash (SPI flash offset) */
	#define DTB_ADDR_RAM		"20500000"	/* Internal RAM location to copy Device Tree */
	#define DTB_ADDR_SDRAM		"09800000"	/* External SDRAM location to copy Device Tree */

	#define MEM_ADDR_RAM		"0x20000000 0x00A00000"	/* System Memory for when using on-chip RAM (10MB) */
	#define MEM_ADDR_SDRAM		"0x08000000 0x02000000"	/* System Memory for when using external SDRAM RAM (32MB) */

	#define KERNEL_ADDR_FLASH	"0x18200000"	/* Flash location of xipImage or uImage binary */
	#define UIMAGE_ADDR_SDRAM	"09000000"	/* Address to copy uImage to in external SDRAM */
	#define UIMAGE_ADDR_SIZE	"0x400000"	/* Size of the uImage binary in Flash (4MB) */


	/* Default kernel command line options */
	setenv("cmdline_common", "ignore_loglevel earlyprintk earlycon=scif,0xE8009000");

	/* Root file system choices */
	setenv("fs_axfs", "rootfstype=axfs rootflags=physaddr=0x18800000");
	setenv("fs_mtd",  "root=/dev/mtdblock0");

	/* LCD Frame buffer location */
	setenv("dtb_lcdfb_fixed", "fdt set /display@fcff7400 fb_phys_addr <0x60000000>");	/* Fixed address */
	setenv("dtb_lcdfb_dyn",   "fdt set /display@fcff7400 fb_phys_addr <0x00000000>");	/* Dynamically allocate during boot */

	/* Read DTB from Flash into either internal on-chip RAM or external SDRAM */
	setenv("dtb_read_ram",   "sf probe 0; sf read "DTB_ADDR_RAM" "DTB_ADDR_FLASH" 8000; fdt addr "DTB_ADDR_RAM" ; setenv addr_dtb "DTB_ADDR_RAM"");
	setenv("dtb_read_sdram", "sf probe 0; sf read "DTB_ADDR_SDRAM" "DTB_ADDR_FLASH" 8000; fdt addr "DTB_ADDR_SDRAM" ; setenv addr_dtb "DTB_ADDR_SDRAM"");

	/* Set the system memory address and size. This overrides the setting in Device Tree */
	setenv("dtb_mem_ram",   "fdt memory "MEM_ADDR_RAM"");		/* Use internal RAM for system memory */
	setenv("dtb_mem_sdram", "fdt memory "MEM_ADDR_SDRAM"");		/* Use external SDRAM for system memory */

	/* Kernel booting operations */
	setenv("xImg", "qspi dual; setenv cmd bootx "KERNEL_ADDR_FLASH" ${addr_dtb}; run cmd");	/* Boot a XIP Kernel */
	setenv("uImg", "qspi dual; cp.b "KERNEL_ADDR_FLASH" "UIMAGE_ADDR_SDRAM" "UIMAGE_ADDR_SIZE"; bootm start "UIMAGE_ADDR_SDRAM" - "DTB_ADDR_SDRAM"; bootm loados ; bootm go");	/* Boot a uImage kernel */

	/* => run xa_boot */
	/* Boot XIP using internal RAM only, file system is AXFS, LCD dynamically allocated */
	//setenv("xa_boot", "run dtb_read_ram; run dtb_mem_ram; run dtb_lcdfb_dyn; setenv bootargs ${cmdline_common} ${fs_axfs}; fdt chosen; run xImg");
	setenv("xa_boot", "cp.b 200c0000 80300000 10000 ; bootx 20200000 80300000");

	/* => run xsa_boot */
	/* Boot XIP using external 32MB SDRAM, file system is AXFS, LCD FB fixed to internal RAM */
	//setenv("xsa_boot", "run dtb_read_sdram; run dtb_mem_sdram; run dtb_lcdfb_fixed; setenv bootargs ${cmdline_common} ${fs_axfs}; fdt chosen; run xImg");
	setenv("xha_boot", "cp.b 200c0000 40300000 10000 ; bootx 20200000 40300000");

	/* => run s_boot */
	/* Boot SDRAM uImage using external 32MB SDRAM, file system is squashfs, LCD FB fixed to internal RAM */
	setenv("s_boot", "run dtb_read_sdram; run dtb_mem_sdram; run dtb_lcdfb_fixed; setenv bootargs ${cmdline_common} ${fs_mtd}; fdt chosen; run uImg");

	/* => run sa_boot */
	/* Boot SDRAM uImage using external 32MB SDRAM, file system is AXFS, LCD FB fixed to internal RAM */
	setenv("sa_boot", "run dtb_read_sdram; run dtb_mem_sdram; run dtb_lcdfb_fixed; setenv bootargs ${cmdline_common} ${fs_axfs}; fdt chosen; run uImg");

	return 0;
}


int dram_init(void)
{
	#if (1 !=  CONFIG_NR_DRAM_BANKS)
	# error CONFIG_NR_DRAM_BANKS must set 1 in this board.
	#endif
	/* SDRAM setup is already done in board_early_init_f */
	gd->bd->bi_dram[0].start = CONFIG_SYS_SDRAM_BASE;
	gd->bd->bi_dram[0].size = CONFIG_SYS_SDRAM_SIZE;
	gd->ram_size = CONFIG_SYS_SDRAM_SIZE * CONFIG_NR_DRAM_BANKS;

	return 0;
}

const struct rmobile_sysinfo sysinfo = {
	CONFIG_ARCH_RMOBILE_BOARD_STRING
};

void reset_cpu(ulong addr)
{
	/* If you have board specific stuff to do, you can do it
	here before you reboot */

	/* Dummy read (must read WRCSR:WOVF at least once before clearing) */
	*(volatile u8 *)(WRCSR) = *(u8 *)(WRCSR);

	*(volatile u16 *)(WRCSR) = 0xA500;     /* Clear WOVF */
	*(volatile u16 *)(WRCSR) = 0x5A5F;     /* Reset Enable */
	*(volatile u16 *)(WTCNT) = 0x5A00;     /* Counter to 00 */
	*(volatile u16 *)(WTCSR) = 0xA578;     /* Start timer */

	while(1); /* Wait for WDT overflow */
}

void led_red_set_state(unsigned short value)
{
	if (value)	/* turn LED on */
		gpio_set(P6,0,1);
	else		/* turn LED off */
		gpio_set(P6,0,0);
}

void led_green_set_state(unsigned short value)
{
	if (value)	/* turn LED on */
		gpio_set(PC,1,1);
	else		/* turn LED off */
		gpio_set(PC,1,0);
}

u8 button_check_state(u8 sw)
{
	/* returns: 1 = button up
		    0 = button pressed
	*/
#if 0
	if (sw == 1)	/* SW 1 */
		return gpio_read(1, 9);
#endif
	return 1;
}

