#ifndef RPMSG_PING_H
#define RPMSG_PING_H

#define RPMSG_SERVICE_NAME         "rpmsg-openamp-demo-channel"

#endif /* RPMSG_PING_H */
