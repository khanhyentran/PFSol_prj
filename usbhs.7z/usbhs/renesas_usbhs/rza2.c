// SPDX-License-Identifier: GPL-2.0
/*
 * Renesas USB driver RZ/A initialization and power control
 *
 * Copyright (C) 2018 Chris Brandt
 * Copyright (C) 2018 Renesas Electronics Corporation
 */

#include <linux/delay.h>
#include <linux/io.h>
#include <linux/of_device.h>
#include "common.h"
#include "rza2.h"



// #define LPSTS		0x102
#define COMMCTRL 	0x800

#define PHYCLK_CTRL 0x844
/* Clock Select for RA/A2 */
#define PHYCLK_CTRL_UCKSEL_EXTAL 		0x0
#define PHYCLK_CTRL_UCKSEL_USB_X1 		0x00000001

#define USBCTR 		0x20C
#define USBCTR_DIRPD 	0x00000004
#define USBCTR_PLL_RST 	0x00000002


/* Common Control Register */
#define COMMCTRL_OTG_PERI_HOST 		0x0
#define COMMCTRL_OTG_PERI_PERIPHERAL 0x80000000

#define LINECTRL1 0x810
#define LINECTRL1_DPRPD_EN (1<<19)
#define LINECTRL1_DMRPD_EN (1<<17)
#define LINECTRL1_DM_RPD (1<<16)
//  Low Power Status register (LPSTS)
#define LPSTS 0x102 
#define LPSTS_SUSPM	0x4000

#define PHYIF_CTRL 0x848
#define PHYIF_CTRL_FIXPHY 0x00000001

static void usbhs_write32(struct usbhs_priv *priv, u32 reg, u32 data)
{
	iowrite32(data, priv->h_base + reg);
}

static u32 usbhs_read32(struct usbhs_priv *priv, u32 reg)
{
	return ioread32(priv->h_base + reg);
}

void usbhs_bset32(struct usbhs_priv *priv, u32 reg, u32 mask, u32 data)
{
	u32 val = usbhs_read32(priv, reg);

	val &= ~mask;
	val |= data & mask;

	usbhs_write32(priv, reg, val);
}
static int usbhs_rza2_hardware_init(struct platform_device *pdev)
{
	struct usbhs_priv *priv = usbhs_pdev_to_priv(pdev);

	usbhs_write32(priv, PHYCLK_CTRL, PHYCLK_CTRL_UCKSEL_EXTAL); //host register
	usbhs_write32(priv, COMMCTRL, COMMCTRL_OTG_PERI_PERIPHERAL); //host register
	usbhs_write32(priv, PHYIF_CTRL, PHYIF_CTRL_FIXPHY); 
	usbhs_write(priv, LPSTS, LPSTS_SUSPM);  //function register
	// usbhs_write(priv, LPSTS, 0x4000);
	usbhs_bset32(priv, USBCTR, USBCTR_PLL_RST, 0); //host register
	udelay(100);
	

	return 0;
}

static int usbhs_rza2_power_ctrl(struct platform_device *pdev,
				void __iomem *base, int enable)
{
	struct usbhs_priv *priv = usbhs_pdev_to_priv(pdev);
	if(enable){
		usbhs_bset(priv, LPSTS, LPSTS_SUSPM, LPSTS_SUSPM);
	/* The controller on RZA2 needs to wait up to 100 usec */
		udelay(100);
	}
	else{
		usbhs_bset(priv, LPSTS, LPSTS_SUSPM, 0);
	}
	return 0;
}

static int usbhs_rza2_hardware_exit(struct platform_device *pdev)
{
	return  0;
}
static int usbhs_rza2_get_id(struct platform_device *pdev)
{
	return USBHS_GADGET;
}

const struct renesas_usbhs_platform_callback usbhs_rza2_ops = {
	.hardware_init = usbhs_rza2_hardware_init,
	.hardware_exit = usbhs_rza2_hardware_exit,
	// .power_ctrl = usbhs_rza2_power_ctrl,
	.get_id = usbhs_rza2_get_id,
};
